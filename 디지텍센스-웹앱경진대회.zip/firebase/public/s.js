
let imageSlideindex = 1;
showImageslides(imageSlideindex);

function imageslidetimer() {
    plusImageSlides(1);
}

let imagetimer = setInterval(imageslidetimer, 3000);

function plusImageSlides(n) {
    clearInterval(imagetimer);  //버튼클릭해서 겹치는거 금지
    imagetimer = setInterval(imageslidetimer, 3000);
    // imageslideindex에 인자로 전달된 n값을 더해줌
    showImageslides(imageSlideindex += n);
}

function currentImageSlide(n) {
    imagetimer = setInterval(imageslidetimer, 3000);
    clearInterval(imagetimer);
    // 인자로 전달된 n값으로 이미지 슬라이드를 초기화하여 보여줌
    showImageslides(imageSlideindex = n);
}

// 인자값으로 전달된 n값을 보고 적절한 슬라이드를 보여줌
// 슬라이드 방식: 모든 슬라이드  none처리
// 이미지 슬라이드 인덱스에 해당되는 것만 보여줌
function showImageslides(n) {
    let slides = document.getElementsByClassName('image-slide');
    let dots = document.getElementsByClassName('dot');
    // 마지막 슬라이드에서 다음 버튼을 눌렀을때 => 첫 번째 슬라이드로 이동
    if (n > slides.length) {
        imageSlideindex = 1;
    }
    // 첫 번째 슬라이드에서 이전 버튼을 눌렀을 때 => 마지막(다섯번 째)슬라이드로 이동
    // n이 1값보다 작다면 5번째 슬라이드 인덱스가 보여짐
    if (n < 1) { imageSlideindex = slides.length }

    // 슬라이드 방식: 모든 슬라이드  none처리
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // dot의 i번째 인덱스 요소에 classname에 active라는 클래스가 있다면 공백으로 제거한 후에 다시 넣어줌
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace('active', '');

    }
    // slides[0]
    slides[imageSlideindex - 1].style.display = "block";
    dots[imageSlideindex - 1].classList.add('active');
    // dots[0]


}


// 점 누르면 다른 슬라이드 나오게 하기

let first = document.getElementById("firstDot").addEventListener('click', function () { currentImageSlide(1); });
let second = document.getElementById("secondDot").addEventListener('click', function () { currentImageSlide(2); });
let third = document.getElementById("thirdDot").addEventListener('click', function () { currentImageSlide(3); });
let forth = document.getElementById("forthDot").addEventListener('click', function () { currentImageSlide(4); });
let fifth = document.getElementById("fifthDot").addEventListener('click', function () { currentImageSlide(5); });
