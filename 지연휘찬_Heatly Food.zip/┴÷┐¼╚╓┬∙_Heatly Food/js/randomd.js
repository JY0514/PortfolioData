let recommend = document.getElementById("recommend");
let bulkupbreak =["아무것도 바꾸지 않으면 변하는 것은 없다"
, "당신이 아무리 천천히 걷고 있다고 해도 쇼파에 엉덩이를 붙이고 있는 사람들보다는 낫다!",
"내 머리는 복근을 쫓으라 말하지만, 내 마음은 도넛에 향한다 ",
"둘 중 어느 것이 더 긴지 모르겠다: 전자레인지 1분인지, 러닝머신에서의 1분인지",
"근육을 붙이려면 몸을 바삐 움직여야지",
"스쿼트를 열심히 하는 자에게 복이 있나니",
"당신의 몸에 귀를 기울여라","다른 사람에게 나의 생활방식에 대해 설명하는 것을 그만두고,<br> 나에게 맞는 데로 살아갈 때 삶이 훨씬 편해진다",
"5% 덜 나가기 위해 당신의 삶 95%를 희생하지는 말아라","나약함이 동반되지 않은 강인함이란 없다"
,"내가 사람을 믿지 못하는 이유는 “이번이 마지막”이라고 말하는 트레이너들 때문이다"
,"당신이 변화의 주역!","죽을것 같지만 죽지않습니다","운동은 새로운 삶의 시작","나를 배부르게 한 것들이 나를 파괴한다"
,"세끼 다 먹으면 살쪄요","인생은 살이 쪘을때와 안 쪘을때로 나뉜다","지금 먹어봤자 내가 다 알고 있는 그 맛이다","너무 배부르면 피곤해진다"] 
let grid = document.getElementById("grid")
let t2 = document.getElementById("t2")
let t1 = document.getElementById("t1")
let t3 = document.getElementById("t3")
let t4 = document.getElementById("t4")
let t5 = document.getElementById("t5")
recommend.addEventListener("click",function (){
   var result = bulkupbreak[Math.floor(Math.random()*19)];
   t1.innerHTML = result
   if(result>=bulkupbreak.length){
      foodArray = 0;
   }
   if(rusult>=bulkupsnak.length){
      snackArray = 0;
   }
   if(rtsult>=bulkuplunch.length){
      lunchArray = 0;
   }
   if(rysult>=lunchsnack.length){
       nextsnackArray = 0;
   }
   if(risult>=bulkupdinner.length){
       dinnerArray = 0;
   }
})


