let recommend = document.getElementById("recommend");
let bulkupbreak =["에일리<br>아침 사과, 닭가슴살,두유,오이<br>점심    고구마 1개, 삶은 계란 1개, 야채 샐러드, 플레인 요거트<br>저녁    새우, 닭가슴살,소고기,게살,야채 2컵,과일"
, "박보람<br> 아침    토마토. 닭 가슴살, 채소, 고구마<br>점심    닭 가슴살 샐러드, 저지방 우유(또는 다이어트 음료)<br>오후 3시    바나나 1개, 삶은 달걀 흰자 3개, 삶은 달걀 노른자 1개<br>오후 6시    고구마 1개, 닭가슴살 1조각, 채소",
" 강민경<br>아침    고구마 1개 저지방 우유 닭가슴살 샐러드<br>점심    고구마 2개  사과 1개<br>저녁    고구마 1개   저지방 우유  방울 토마토","아이유<br>하루식단    고구마 1개  단백질 음료 1잔  사과 1개",
"박신혜<br>아침    오이 1개  저지방 우유 1잔<br>점심    밥 1/2  공기  배추 조금<br>저녁    오이 1개  배추 조금",
"박규리<br>옵션1    닭가슴살  계란  생선  무지방 우유<br>옵션2      순수 단백질 식단  야채샐러드  토마토 주스<br>옵션3    순수 단백질 식단  녹색채소  단백질  감자(조금)<br>옵션4    순수 단백질 식단  나물  야채",
"소유 <br>아침    잡곡밥  김치찌개  계란말이<br>점심    탄수화물 조금 (고구마 옥수수 등) 단백질 (두부  계란 등)<br>저녁    닭가슴",
"강소라<br>아침    요거트  사과 1개<br>점심    백반  채소 반찬   호박죽<br>저녁    고구마 1개 양상추 식빵 1개"] 
let grid = document.getElementById("grid")
let t2 = document.getElementById("t2")
let t1 = document.getElementById("t1")
let t3 = document.getElementById("t3")
let t4 = document.getElementById("t4")
let t5 = document.getElementById("t5")
recommend.addEventListener("click",function (){
   var result = bulkupbreak[Math.floor(Math.random()*8)];
   t1.innerHTML = result
   if(result>=bulkupbreak.length){
      foodArray = 0;
   }
   if(rusult>=bulkupsnak.length){
      snackArray = 0;
   }
   if(rtsult>=bulkuplunch.length){
      lunchArray = 0;
   }
   if(rysult>=lunchsnack.length){
       nextsnackArray = 0;
   }
   if(risult>=bulkupdinner.length){
       dinnerArray = 0;
   }
})


