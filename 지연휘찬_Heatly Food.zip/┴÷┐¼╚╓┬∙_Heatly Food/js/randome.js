let recommend = document.getElementById("recommend");
let bulkupbreak =["아침식사:시금치 오믈렛 (계란 6개 사용)","아침식사:많은 양의 그래놀라 시리얼, 우유, 바나나 1개"
, "아침식사:베이글 2개, 땅콩 버터","아침식사:삶은 계란 2개, 구운 연어, 아보카도 1개"] 
let bulkupsnak =["아침간식:한 줌의 아몬드","아침간식:땅콩 버터를 곁들인 사과","아침간식닭가슴살, 토마토, 양상추, 현미밥 조금","아침간식:단백질 보충제, 우유"] 
let bulkuplunch = ["점심식사:현미밥, 구운 닭가슴살, 브로콜리","점심식사:구운 연어, 고구마, 채소 샐러드","점심식사:현미밥, 고등어 구이, 채소 샐러드"
,"점심식사:치킨 칠리 부리토, 우유","점심식사:통조림 참치, 퀴노아, 아보카도, 브로콜리"]
let lunchsnack = ["점심간식:다크 초콜릿 (먹을 수 있을 만큼)","점심간식:단백질 보충제, 우유","점심간식:혼합 견과류 한 줌","점심간식:육포"]
let bulkupdinner =["저녁식사:참치 스테이크, 고구마 2개, 퀴노아, 채소 샐러드, 올리브 오일",
"저녁식사:쇠고기 등심 스테이크, 현미밥, 계란 후라이",
"저녁식사:돼지 등심 구이, 구운 감자, 통곡물 빵",
"저녁식사:참치 통조림, 볼로네즈 소스, 파스타",] 
let grid = document.getElementById("grid")
let t2 = document.getElementById("t2")
let t1 = document.getElementById("t1")
let t3 = document.getElementById("t3")
let t4 = document.getElementById("t4")
let t5 = document.getElementById("t5")
recommend.addEventListener("click",function (){
   var result = bulkupbreak[Math.floor(Math.random()*4)];
   var rusult = bulkupsnak[Math.floor(Math.random()*4)];
   var rtsult = bulkuplunch[Math.floor(Math.random()*5)];
   var rysult = lunchsnack[Math.floor(Math.random()*4)];
   var risult = bulkupdinner[Math.floor(Math.random()*4)];
   t1.innerHTML = result
   t2.innerHTML = rusult
   t3.innerHTML = rtsult
   t4.innerHTML = rysult
   t5.innerHTML = risult
   if(result>=bulkupbreak.length){
      foodArray = 0;
   }
   if(rusult>=bulkupsnak.length){
      snackArray = 0;
   }
   if(rtsult>=bulkuplunch.length){
      lunchArray = 0;
   }
   if(rysult>=lunchsnack.length){
       nextsnackArray = 0;
   }
   if(risult>=bulkupdinner.length){
       dinnerArray = 0;
   }
})


