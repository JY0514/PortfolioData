var myImage = document.getElementById("mainimg");
var imageArray = ["../img/11.jpeg", "../img/111.jpg", "../img/food2.jpeg", "../img/food3.jpg","../img/food1.jpg"];
var imageindex = 0;

function changeImage(){
    myImage.style.backgroundImage=`url(${imageArray[imageindex]})`; 
    imageindex++;
    if(imageindex>=imageArray.length){
        imageindex=0;
    }
}
setInterval(changeImage,3000);

 