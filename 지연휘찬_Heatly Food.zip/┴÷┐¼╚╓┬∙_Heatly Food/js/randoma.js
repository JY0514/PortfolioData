let recommend = document.getElementById("recommend");
let bulkupbreak =["아침: 과일 샐러드","아침: 식물성 우유 한 잔과 빵, 아보카도 퓌레와 토마토"
, "아침: 오렌지 한 개로 만든 주스, 배와 키위, 견과류 한 줌, 샐러드와 오일을 곁들인 토스트 1장",
"아침: 배와 복숭아, 식물성 우유 한 잔과 견과류 한 줌","아침: 식물성 우유 한 잔과 비건 귀리, 코코넛 비스킷",
"아침: 오트밀 우유와 차, 잼과 빵"] 
let bulkupsnak =["오전 중: 견과류 한 줌","오전 중: 여러 가지 신선한 과일",
"오전 중: 식물성 우유 한 잔과 비건 비스킷","오전 중: 사과와 키위, 통곡물 비스킷",
] 
let bulkuplunch = ["점심: 팔라펠과 채소를 곁들인 후무스 랩","점심: 아스파라거스를 곁들인 퀴노아 샐러드와 딸기",
"점심: 토마토와 릭 수프, 토마토와 타임을 곁들인 귀리 “미트볼”"
,"점심: 배와 채소 샐러드, 토마토와 두부를 곁들인 파스타",
"점심: 콩과 버섯 버거, 구운 감자",
"점심: 토마토를 곁들인 브루스케타, 후추를 뿌린 밥"]
let lunchsnack = ["오후 간식: 식물성 우유(코코넛, 아몬드나 두유)과 토마토와 오일을 곁들인 토스트","오후 간식: 식물성 우유 한 잔과 해바라기 씨 1큰술","오후 간식: 사과와 헤이즐넛 한 줌(20 gm)","오후 간식: 귤 2개"
,"오후 간식: 식물성 우유와 아보카도 퓌레와 토마토를 곁들인 빵","오후 간식: 과일 2조각"]
let bulkupdinner =["저녁: 비건 피자",
"저녁: 브로콜리, 스쿼시(호박 같은 것) 및 두부볶음",
"저녁: 병아리콩 샐러드, 현미와 두부, 빵과 잼을 넣은 두유 요거트",
"저녁: 채소와 밀고기(고단백 저지방 밀 글루텐), 식물성 우유 한 잔",
"저녁: 블랙 마늘 소스를 곁들인 두부와 비건 마요네즈와 빨간 양배추 샐러드",
"저녁: 비건 오믈렛과 버섯"] 
let grid = document.getElementById("grid")
let t2 = document.getElementById("t2")
let t1 = document.getElementById("t1")
let t3 = document.getElementById("t3")
let t4 = document.getElementById("t4")
let t5 = document.getElementById("t5")
recommend.addEventListener("click",function (){
   var result = bulkupbreak[Math.floor(Math.random()*4)];
   var rusult = bulkupsnak[Math.floor(Math.random()*4)];
   var rtsult = bulkuplunch[Math.floor(Math.random()*5)];
   var rysult = lunchsnack[Math.floor(Math.random()*4)];
   var risult = bulkupdinner[Math.floor(Math.random()*4)];
   t1.innerHTML = result
   t2.innerHTML = rusult
   t3.innerHTML = rtsult
   t4.innerHTML = rysult
   t5.innerHTML = risult
   if(result>=bulkupbreak.length){
      foodArray = 0;
   }
   if(rusult>=bulkupsnak.length){
      snackArray = 0;
   }
   if(rtsult>=bulkuplunch.length){
      lunchArray = 0;
   }
   if(rysult>=lunchsnack.length){
       nextsnackArray = 0;
   }
   if(risult>=bulkupdinner.length){
       dinnerArray = 0;
   }
})


