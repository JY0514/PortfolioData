let recommend = document.getElementById("recommend");
let foodArray = ["아침식사:녹색스무디(바나나1/2+냉동망고1/2컵 +케일1컵+<br>그릭요거트1/2+아보카도1/2+저지방우유1/2컵)","아침식사:베리 스무디(바나나1/2)+냉동 딸기 1컵 + 그릭요거트1/2컵+무지방 우유1/2컵)"
, "아침식사:귀리 스무디(귀리1/2컵+치아스디1테이블 스푼+<br>무지방 우유1/2컵+그릭 요거트1.2컵+블루베리1/2컵","아침식사:통밀 토스트 2조각+삶은 계란 2개+땅콩 버터 약간"]
let snackArray = ["아침간식:사과1개+아몬드약간","아침간식:바나나1개+견과류 약간","아침간식:블루베리1컵+견과류 약간"]
let lunchArray = ["점심 식사 : 야채 수프 2 컵","점심 식사 : 닭고기 + 퀴노아 ½ 컵 + 방울 토마토 1컵 + 다진 오이 1 컵<br> + 슬라이스 치즈 1장 + 데리야끼 소스","점심 식사 : 참치 + 혼합 채소 2 컵 + 방울 토마토 1 컵 + 다진 오이 1 컵 + 머스터드 소스 1 큰술","점심 식사 : 칠면조 가슴살 + 아보카도 ¼ + 옥수수 1컵 + 혼합 채소 1 컵","점심 식사 : 연어 + 아보카도 ¼ + 옥수수 1 컵 + 혼합 채소 1 컵"]
let nextsnackArray = ["오후 간식 : 베이비 당근 1 개 + 완두콩 + 머스터드 2 큰술","오후 간식 : 브로콜리 & 콜리 플라워 1 컵 + 데리야끼 소스 2 큰술","오후 간식 : 당근 1 개 & 완두콩 + 머스터드 2 큰술","오후 간식 : 브로콜리 1컵 + 콜리 플라워 1 컵 + 데리야끼 소스 2 큰술","오후 간식 : 브로콜리 1 컵 + 데리야끼 소스 2 큰술"]
let dinnerArray = ["저녁 식사 : 스테이크 소고기 + 구운 고구마 1 컵 + 구운 당근 1 컵 + 올리브 오일 1 큰술<br> 조리방법:달궈진 프라이팬에 올리브 오일을 두른 후 스테이크 소고기를 올려 구우세요.<br> 덜 익힌 고기는 식중독의 위험이 높아지기 때문에 소고기를 완전히 익히세요.<br>소금과 후추로 간을 하세요. 접시에 스테이크를 올려놓고 구운 고구마와 구운 당근으로 장식을 하세요.",
                     "저녁 식사 : 연어 + 당근 1 컵 + 브로콜리 1 컵 + 데리야끼 소스 2 큰술 + 참깨 1 티스푼<br> 조리방법:두께에 따라 10 ~ 15 분 동안 익을 때까지 연어를 굽습니다. <br>당근과 브로콜리를 자르고 부드러워 질 때까지 볶습니다<br> (당근은 약 5 분, 브로콜리는 3 분). 데리야끼 소스로 모든 것을 뿌린 후 참깨를 뿌립니다.",
                     "저녁 식사 : 닭고기 + 고구마 ½ 컵 + 당근 1 컵 + 올리브 오일 1 큰술<br> 조리방법:고구마를 자르고 당근을 반으로 자른 후 프라이팬 위에 올려 놓습니다. <br>올리브유 2 티스푼을 뿌린 후 소금과 후추로 간을 한 다음 뿌린다. 약 15 분 정도 구우세요.<br>닭고기를 구우면서 1 티스푼의 올리브 오일로 넣고 소금과 후추로 간을 합니다.<br>닭고기가 더 이상 분홍색으로 표시되지 않을 때까지 중간 정도 높은 열에 구워냅니다.",
                     "저녁 식사 : 돼지고기 + 당근 1 컵 + 브로콜리 1 컵 + 데리야끼 소스 2 큰술 + 참깨 1 티스푼<br> 조리방법:돼지고기 두께에 따라 10 ~ 15 분 동안 프라이팬에서 굽습니다. 당근과 브로콜리의 경우 약 5 분, <br>당근의 경우 약 5 분 동안 부드러워 질 때까지 당근과 브로콜리를 자르고 굽습니다. 데리야끼 소스를 뿌린 후 참깨를 뿌립니다.",
                     "저녁 식사 : 새우 2 컵 + 당근 1 컵 + 브로콜리 1 컵 + 현미 ½ 컵 + 데리야끼 소스 2 큰술 + 참깨 1 티스푼<br>"]
let grid = document.getElementById("grid")
let h2 = document.getElementById("h2")
let h1 = document.getElementById("h1")
let h3 = document.getElementById("h3")
let h4 = document.getElementById("h4")
let h5 = document.getElementById("h5")
recommend.addEventListener("click",function (){
   var result = foodArray[Math.floor(Math.random()*4)];
   var rusult = snackArray[Math.floor(Math.random()*3)];
   var rtsult = lunchArray[Math.floor(Math.random()*5)];
   var rysult = nextsnackArray[Math.floor(Math.random()*5)];
   var risult = dinnerArray[Math.floor(Math.random()*3)];
   h1.innerHTML = result
   h2.innerHTML = rusult
   h3.innerHTML = rtsult
   h4.innerHTML = rysult
   h5.innerHTML = risult
   if(result>=foodArray.length){
      foodArray = 0;
   }
   if(rusult>=snackArray.length){
      snackArray = 0;
   }
   if(rtsult>=lunchArray.length){
      lunchArray = 0;
   }
})


