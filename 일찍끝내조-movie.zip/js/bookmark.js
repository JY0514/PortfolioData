const kmdbKey = "99GX0A67J6468T9YJ2I8"
const kmdbUrl = `http://api.koreafilm.or.kr/openapi-data2/wisenut/search_api/search_json2.jsp?collection=kmdb_new2&ServiceKey=${kmdbKey}`
let result = document.getElementById("result");
let movieCode = JSON.parse(localStorage.getItem(`BM_list`));

let storageNum = localStorage.getItem('BMnum')
console.log(storageNum);
function BM_load() {
    result.innerHTML = ""
    
    for (let i = 0; i < storageNum; i++) {
        console.log(movieCode[i]);
        fetch(kmdbUrl+`&listCount=1&movieId=${movieCode[i][0]}&movieSeq=${movieCode[i][1]}`)
            .then(response=>response.json())
            .then((data)=>{
                console.log(data.Data[0].Result[0])
                let title = data.Data[0].Result[0].title;
                let postersUrl = data.Data[0].Result[0].posters.split("|");
                let movieId = data.Data[0].Result[0].movieId
                let movieSeq = data.Data[0].Result[0].movieSeq

                result.innerHTML+=`<div class="movieBox"><a href="./movieInfo.html" onclick="movieInfo('${movieId}','${movieSeq}')" target="_blank">
                <div class="posterBox">
                <img src=${postersUrl==""?"./images/no-img.png":postersUrl[0]} alt="poster">
                </div>
                <p>${title.replace(/\!HS|!HE/g, "")}</p>
                </a><button class="btn" onclick="listRemove(${i})">삭제</button></div>`
            })
    }   
}

function listRemove(num) {
    movieCode.splice(num, 1)
    localStorage.setItem(`BM_list`, JSON.stringify(movieCode))
    storageNum--
    localStorage.setItem(`BMnum`, storageNum)
    BM_load()
}

function movieInfo(id, seq) {
    let movieCode = [id, seq];
    console.log(movieCode);
    localStorage.setItem(`movieInfo`, JSON.stringify(movieCode))
}

window.onload = BM_load()